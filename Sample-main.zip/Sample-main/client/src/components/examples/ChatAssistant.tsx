import ChatAssistant from "../ChatAssistant";

export default function ChatAssistantExample() {
  return (
    <div className="p-6 max-w-2xl">
      <ChatAssistant />
    </div>
  );
}
