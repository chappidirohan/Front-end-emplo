import { z } from "zod";

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export type LoginCredentials = z.infer<typeof loginSchema>;

export interface AuthResponse {
  token: string;
}

export interface DecodedToken {
  roles: string;
  username: string;
  exp: number;
}
